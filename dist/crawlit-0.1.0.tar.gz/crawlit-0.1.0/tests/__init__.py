#!/usr/bin/env python3
"""
Test suite for crawlit package
"""

