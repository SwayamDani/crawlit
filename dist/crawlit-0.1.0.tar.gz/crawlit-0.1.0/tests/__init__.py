#!/usr/bin/env python3
"""
Test package for the crawlit web crawler
"""

# This file makes the tests directory a Python package